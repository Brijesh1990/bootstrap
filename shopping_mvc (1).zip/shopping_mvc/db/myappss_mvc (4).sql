-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2018 at 12:42 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myappss_mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catid` int(11) NOT NULL,
  `catname` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catid`, `catname`, `description`) VALUES
(1, 'Electronics appliences', 'good '),
(2, 'shoes', 'good'),
(3, 'formals clothes ', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE `color` (
  `colid` int(11) NOT NULL,
  `colname` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `created_time` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`colid`, `colname`, `created_date`, `created_time`, `description`) VALUES
(4, 'green', '25/05/18', '16:52:53 pm', 'good11111'),
(5, 'yellow', '25/05/18', '16:53:04 pm', 'good'),
(6, 'blue', '25/05/18', '16:53:16 pm', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `pimages` varchar(255) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `colid` int(11) NOT NULL,
  `sizeid` int(11) NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `created_time` varchar(255) NOT NULL,
  `pdescription` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `catid`, `subcatid`, `pimages`, `pname`, `qty`, `price`, `colid`, `sizeid`, `created_date`, `created_time`, `pdescription`) VALUES
(1, 3, 1, 'upload/i5.jpg', 'woodland shoes', 1, 3500, 4, 2, '28/05/18', '17:13:59 pm', 'good products'),
(2, 2, 1, 'upload/w.jpg', 'woodland ninja01', 1, 4500, 6, 2, '30/05/18', '16:59:39 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(3, 2, 1, 'upload/w1.jpg', 'wood naro', 1, 5000, 4, 2, '30/05/18', '17:00:17 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(4, 2, 1, 'upload/w2.jpg', 'woodland', 1, 3500, 4, 2, '30/05/18', '17:04:52 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(5, 2, 1, 'upload/w3.jpg', 'woodland', 1, 4600, 4, 2, '30/05/18', '17:05:29 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(6, 2, 1, 'upload/w5.jpg', 'woodland', 4, 10000, 5, 2, '30/05/18', '17:08:37 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(7, 2, 1, 'upload/w6.jpg', 'woodland', 15, 6000, 4, 2, '30/05/18', '17:09:15 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(8, 2, 1, 'upload/w8.jpg', 'woodland', 1, 4899, 4, 2, '30/05/18', '17:09:52 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(9, 2, 1, 'upload/w7.jpg', 'woodland formal', 66, 4999, 4, 2, '30/05/18', '17:10:32 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(10, 2, 1, 'upload/w9.jpg', 'woodland ', 6, 4999, 4, 2, '30/05/18', '17:11:06 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(11, 2, 1, 'upload/w10.jpg', 'woodland shoes', 6, 299, 4, 2, '30/05/18', '17:11:47 pm', 'Mteraial : Fabric\r\nFoot Friendly\r\nOcassion: Casual\r\nDaily outfit'),
(12, 1, 7, 'upload/m.jpg', 'LAVA Z5', 5, 4980, 5, 2, '30/05/18', '17:14:47 pm', '13+13MP dual back camera (f/2.0, dual LED flash) and 8MP front facing camera with flash\r\n4GB RAM and 64GB internal memory expandable up to 128GB\r\n13.97cms (5.5-inch) Full HD (1080 x 1920) capacitive touchscreen with Gorilla Glass 3 protection\r\nDual nano hybrid SIM with dual-standby (4G+4G); Metal body with fingerprint reader\r\nAndroid v7.1 Nougat operating system with 2.0GHz Snapdragon 625 octa-core processor\r\n3000mAH Lithium-ion battery with 15W Turbo Charging\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including battery from the date of purchase'),
(13, 1, 7, 'upload/m1.jpg', 'LAVA T6', 15, 6987, 4, 2, '30/05/18', '17:15:33 pm', '13+13MP dual back camera (f/2.0, dual LED flash) and 8MP front facing camera with flash\r\n4GB RAM and 64GB internal memory expandable up to 128GB\r\n13.97cms (5.5-inch) Full HD (1080 x 1920) capacitive touchscreen with Gorilla Glass 3 protection\r\nDual nano hybrid SIM with dual-standby (4G+4G); Metal body with fingerprint reader\r\nAndroid v7.1 Nougat operating system with 2.0GHz Snapdragon 625 octa-core processor\r\n3000mAH Lithium-ion battery with 15W Turbo Charging\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including battery from the date of purchase'),
(14, 1, 7, 'upload/m5.jpg', 'IPHONE 6', 3, 22500, 5, 2, '30/05/18', '17:16:25 pm', '13+13MP dual back camera (f/2.0, dual LED flash) and 8MP front facing camera with flash\r\n4GB RAM and 64GB internal memory expandable up to 128GB\r\n13.97cms (5.5-inch) Full HD (1080 x 1920) capacitive touchscreen with Gorilla Glass 3 protection\r\nDual nano hybrid SIM with dual-standby (4G+4G); Metal body with fingerprint reader\r\nAndroid v7.1 Nougat operating system with 2.0GHz Snapdragon 625 octa-core processor\r\n3000mAH Lithium-ion battery with 15W Turbo Charging\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including battery from the date of purchase'),
(15, 1, 7, 'upload/m3.jpg', 'LAVA Z7', 6, 17500, 4, 2, '30/05/18', '17:17:02 pm', '13+13MP dual back camera (f/2.0, dual LED flash) and 8MP front facing camera with flash\r\n4GB RAM and 64GB internal memory expandable up to 128GB\r\n13.97cms (5.5-inch) Full HD (1080 x 1920) capacitive touchscreen with Gorilla Glass 3 protection\r\nDual nano hybrid SIM with dual-standby (4G+4G); Metal body with fingerprint reader\r\nAndroid v7.1 Nougat operating system with 2.0GHz Snapdragon 625 octa-core processor\r\n3000mAH Lithium-ion battery with 15W Turbo Charging\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including battery from the date of purchase'),
(16, 1, 7, 'upload/m2.jpg', 'One Plus 4', 6, 15000, 4, 2, '30/05/18', '17:17:41 pm', '13+13MP dual back camera (f/2.0, dual LED flash) and 8MP front facing camera with flash\r\n4GB RAM and 64GB internal memory expandable up to 128GB\r\n13.97cms (5.5-inch) Full HD (1080 x 1920) capacitive touchscreen with Gorilla Glass 3 protection\r\nDual nano hybrid SIM with dual-standby (4G+4G); Metal body with fingerprint reader\r\nAndroid v7.1 Nougat operating system with 2.0GHz Snapdragon 625 octa-core processor\r\n3000mAH Lithium-ion battery with 15W Turbo Charging\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including battery from the date of purchase'),
(17, 1, 7, 'upload/m6.jpg', 'Samsung Guru', 5, 2999, 5, 2, '30/05/18', '17:18:24 pm', '13+13MP dual back camera (f/2.0, dual LED flash) and 8MP front facing camera with flash\r\n4GB RAM and 64GB internal memory expandable up to 128GB\r\n13.97cms (5.5-inch) Full HD (1080 x 1920) capacitive touchscreen with Gorilla Glass 3 protection\r\nDual nano hybrid SIM with dual-standby (4G+4G); Metal body with fingerprint reader\r\nAndroid v7.1 Nougat operating system with 2.0GHz Snapdragon 625 octa-core processor\r\n3000mAH Lithium-ion battery with 15W Turbo Charging\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including battery from the date of purchase'),
(18, 1, 7, 'upload/m9.jpg', 'Nokia 2690', 5, 1999, 4, 2, '30/05/18', '17:18:54 pm', '13+13MP dual back camera (f/2.0, dual LED flash) and 8MP front facing camera with flash\r\n4GB RAM and 64GB internal memory expandable up to 128GB\r\n13.97cms (5.5-inch) Full HD (1080 x 1920) capacitive touchscreen with Gorilla Glass 3 protection\r\nDual nano hybrid SIM with dual-standby (4G+4G); Metal body with fingerprint reader\r\nAndroid v7.1 Nougat operating system with 2.0GHz Snapdragon 625 octa-core processor\r\n3000mAH Lithium-ion battery with 15W Turbo Charging\r\n1 year manufacturer warranty for device and 6 months manufacturer warranty for in-box accessories including battery from the date of purchase'),
(19, 1, 8, 'upload/r.jpg', 'LG joy', 2, 17850, 5, 2, '30/05/18', '17:20:16 pm', 'This product comes ready to use and does not require installation or demo. All product features are presented in the user manual that comes with the product.\r\nDirect Cool Single Door: Economical, requires manual defrosting\r\nCapacity 195 L: Suitable for families with 2 to 3 members\r\nEnergy Rating: 4 Star'),
(20, 1, 8, 'upload/r1.jpg', 'LG 175 L', 3, 18950, 4, 2, '30/05/18', '17:21:06 pm', 'This product comes ready to use and does not require installation or demo. All product features are presented in the user manual that comes with the product.\r\nDirect Cool Single Door: Economical, requires manual defrosting\r\nCapacity 195 L: Suitable for families with 2 to 3 members\r\nEnergy Rating: 4 Star'),
(21, 1, 8, 'upload/r2.jpg', 'SAMSUNG DOUBLE DOOR 650L', 5, 22560, 4, 2, '30/05/18', '17:22:09 pm', 'This product comes ready to use and does not require installation or demo. All product features are presented in the user manual that comes with the product.\r\nDirect Cool Single Door: Economical, requires manual defrosting\r\nCapacity 195 L: Suitable for families with 2 to 3 members\r\nEnergy Rating: 4 Star'),
(22, 1, 8, 'upload/r3.jpg', 'OLA 250L', 5, 2500, 4, 2, '30/05/18', '17:34:45 pm', 'This product comes ready to use and does not require installation or demo. All product features are presented in the user manual that comes with the product.\r\nDirect Cool Single Door: Economical, requires manual defrosting\r\nCapacity 195 L: Suitable for families with 2 to 3 members\r\nEnergy Rating: 4 Star'),
(23, 1, 8, 'upload/r4.jpg', 'LG 650L', 5, 22500, 5, 2, '30/05/18', '17:35:19 pm', 'This product comes ready to use and does not require installation or demo. All product features are presented in the user manual that comes with the product.\r\nDirect Cool Single Door: Economical, requires manual defrosting\r\nCapacity 195 L: Suitable for families with 2 to 3 members\r\nEnergy Rating: 4 Star'),
(24, 1, 8, 'upload/r5.jpg', 'LG 350L', 5, 25000, 4, 2, '30/05/18', '17:35:51 pm', 'This product comes ready to use and does not require installation or demo. All product features are presented in the user manual that comes with the product.\r\nDirect Cool Single Door: Economical, requires manual defrosting\r\nCapacity 195 L: Suitable for families with 2 to 3 members\r\nEnergy Rating: 4 Star'),
(25, 1, 8, 'upload/r7.jpg', 'SAMSUNG 950L', 5, 65000, 6, 2, '30/05/18', '17:36:36 pm', 'This product comes ready to use and does not require installation or demo. All product features are presented in the user manual that comes with the product.\r\nDirect Cool Single Door: Economical, requires manual defrosting\r\nCapacity 195 L: Suitable for families with 2 to 3 members\r\nEnergy Rating: 4 Star');

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE `size` (
  `sizeid` int(11) NOT NULL,
  `sizename` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `created_time` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`sizeid`, `sizename`, `created_date`, `created_time`, `description`) VALUES
(2, '10', '25/05/18', '17:32:15 pm', 'good | good');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `subcatid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `subcatname` varchar(255) NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `created_time` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`subcatid`, `catid`, `subcatname`, `created_date`, `created_time`, `description`) VALUES
(1, 3, 'sports shoes', '23/05/18', '16:41:07 pm', 'good and very comforts'),
(2, 2, 'sports shirt', '23/05/18', '16:41:25 pm', 'good for health'),
(7, 1, 'Mobile', '30/05/18', '17:12:47 pm', 'good'),
(8, 1, 'Refrigirator', '30/05/18', '17:13:28 pm', 'good');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`colid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `catid` (`catid`),
  ADD KEY `subcatid` (`subcatid`),
  ADD KEY `colid` (`colid`),
  ADD KEY `sizeid` (`sizeid`);

--
-- Indexes for table `size`
--
ALTER TABLE `size`
  ADD PRIMARY KEY (`sizeid`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`subcatid`),
  ADD KEY `catid` (`catid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `color`
--
ALTER TABLE `color`
  MODIFY `colid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `size`
--
ALTER TABLE `size`
  MODIFY `sizeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `subcatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
