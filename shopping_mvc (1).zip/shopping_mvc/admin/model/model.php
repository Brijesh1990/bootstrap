<?php
include("config.php");

$obj=new connection();

$c=$obj->conn();
//model class create here..
class model

{
	
//create a member funtion for admin login...

   public function adminlog($c,$table,$em,$pass)
   
   {

    $sel="select * from $table where email='$em' and password='$pass'";

	
	$ex=$c->query($sel);
	
	
	$fet=$ex->fetch_array();
	
	
	$no=$ex->num_rows;
	
	
	if($no > 0)


 {
	 
	$_SESSION["aid"]=$fet["aid"];
	
	 
	$_SESSION["em"]=$fet["email"];
	
	
	
	echo "<script>
	alert('Admin Login succefully')
	
	
	window.location='dashboard.php';
	
	
	</script>";
	
	 
	 
 }
 
 else
 {
	 
	
	
	echo "<script>
	alert('Username and password are Wrong Try again')
	
	
	window.location='index.php';
	
	
	</script>"; 
 }
    	   
	   
	   
	   
	   
   }
	
	
	
	//for logout create a member function..
	
	
	public function logout($aid)
	
	{
		  
		  unset($_SESSION["aid"]);
		  
		  
		  unset($_SESSION["em"]);
		  
		  session_destroy();
		  
		 
	echo "<script>
	alert('Admin Logout succefully')
	
	
	window.location='index.php';
	
	
	</script>"; 
		
	}
	
	
	
	
	
	//create member function for insert all data....
	
	public function insalldata($c,$table,$data)
	
	
	{
		
		
		$k=array_keys($data);
		
		$kk=implode(",",$k);
		
		
		$v=array_values($data);
		
		$vv=implode("','",$v);
		
		$ins="insert into $table($kk) values ('$vv')"; 
		
		$ex=$c->query($ins);
		
		
		}
		
		
		
	//display all data.....	
	
	
	public function shwalldata($c,$table)
	
	{
		
	   $sel="select * from $table";
	   
	   $ex=$c->query($sel);
	   
	   while($fet=$ex->fetch_object())
	   
	   {
		   
		$arr[]=$fet;   
		   
	   }
	   
	   return $arr;
	   
	   	
		
		
	}
	
	
	
	
	//create a meber function for delete data...
	
	
	public function deldata($c,$table,$did)
	
	{

     $del="delete from $table where catid='$did'";
	 
	 $ex=$c->query($del);
	 
	 echo "<script>
	 
	 alert('Category Deleted succefully')
	 
	 window.location='showcategory.php';
	 
	 
	 </script>";
   
   
	}
	
	
	//fetch category from table create member function...
	
	public function fetchcat($c,$table,$eid)
	
	{
		
       $sel="select * from $table where catid='$eid'";
	  
	   $ex=$c->query($sel);
	   
	  $fet=$ex->fetch_array();
	   
	  $arr[]=$fet;   
	
	   return $arr;	
		
		
	}
	
	
	//for update category create a member function...
	
	
	
	public function updcat($c,$table,$catname,$desc,$eid)
	
	
	{
		
		
	$upd="update $table set catname='$catname',description='$desc' where catid='$eid'";
	
	
	$ex=$c->query($upd);
	
	 echo "<script>
	 
	 alert('Category Updated succefully')
	 
	 window.location='showcategory.php';
	 
	 
	 </script>";
   	
		
		
		
		
		
		
		
		
		
	}
	
	
	//show subcategory all data...
	
	public function shwsubcat($c,$tab,$tab1)
	
	{
		
	   $sel="select $tab.*,catname from $tab join $tab1 on $tab.catid=$tab1.catid order by subcatid asc";
	   
	   $ex=$c->query($sel);
	   
	   while($fet=$ex->fetch_array())
	   {
		   
		   
		   $arr[]=$fet;
		   
		   
	   }
	   
	   
	   return $arr;
		
		
	}
	
	
	
	
	
	//create a meber function for delete data...
	
	
	public function delsubdata($c,$table,$did)
	
	{

     $del="delete from $table where subcatid='$did'";
	 
	 $ex=$c->query($del);
	 
   
	}
	
	
	
	//edit subcategory....
	
	
	public function editsubcat($c,$tab,$tab1,$eid)
	
	{
		
	  $sel="select $tab.*,catname from $tab join $tab1 on $tab.catid=$tab1.catid where subcatid='$eid'";
	
	   $ex=$c->query($sel);
	   
	   while($fet=$ex->fetch_array())
	   {
		   
		   
		   $arr[]=$fet;
		   
		   
	   }
	   
	   return $arr;
	
	
	
}




	//for update subcategory create a member function...
	
	
	
	public function updsubcat($c,$table,$cat,$subcat,$desc,$eid)
	
	
	{
		
		
	$upd="update $table set catid='$cat',subcatname='$subcat',description='$desc' where subcatid='$eid'";
	
	
	$ex=$c->query($upd);
	
	 echo "<script>
	 
	 alert('SubCategory Updated succefully')
	 
	 window.location='showsubcatgory.php';
	 
	 
	 </script>";
   	
		
		
		
		
		
		
		
		
		
	}
	
	//create a meber function for delete data for color...
	
	
	public function delcolor($c,$table,$did)
	
	{

     $del="delete from $table where colid='$did'";
	 
	 $ex=$c->query($del);
	 
	 echo "<script>
	 
	 alert('Category Deleted succefully')
	 
	 window.location='showcolor.php';
	 
	 
	 </script>";
   
   
	}
	
	//fetch color from table create member function...
	
	public function fetchcol($c,$table,$eid)
	
	{
		
       $sel="select * from $table where colid='$eid'";
	  
	   $ex=$c->query($sel);
	   
	  $fet=$ex->fetch_array();
	   
	  $arr[]=$fet;   
	
	   return $arr;	
		
		
	}
	
	//for update color create a member function...
	
	
	
	public function updcol($c,$table,$colname,$desc,$eid)
	
	
	{
		
		
	 $upd="update $table set colname='$colname',description='$desc' where colid='$eid'";
	
	
	
	$ex=$c->query($upd);
	
	 echo "<script>
	 
	 alert('Color Updated succefully')
	 
	 window.location='showcolor.php';
	 
	 
	 </script>";
   	
		
		
		
		
		
		
		
		
		
	}
	
	
	//create a meber function for delete data for color...
	
	
	public function delsize($c,$table,$did)
	
	{

      $del="delete from $table where sizeid='$did'"; 
	 
	 $ex=$c->query($del);
	 
	
   
	}
	
	
	
	
	
	//fetch Size from table create member function...
	
	public function fetchsize($c,$table,$eid)
	
	{
		
       $sel="select * from $table where sizeid='$eid'";
	  
	   $ex=$c->query($sel);
	   
	  $fet=$ex->fetch_array();
	   
	  $arr[]=$fet;   
	
	   return $arr;	
		
		
	}
	
	
	
	
	//for update color create a member function...
	
	
	
	public function updsize($c,$table,$sizename,$desc,$eid)
	
	
	{
		
		
	 $upd="update $table set sizename='$sizename',description='$desc' where sizeid='$eid'";
	
	
	
	$ex=$c->query($upd);
	
	 echo "<script>
	 
	 alert('Size Updated succefully')
	 
	 window.location='showsize.php';
	 
	 
	 </script>";
   	
		
		
		}
		
		
		
		
		
	//show  all products data...
	
	public function shwproduct($c,$tab,$tab1,$tab2,$tab3,$tab4,$pid)
	
	{
		
	   $sel="select $tab.*,catname,subcatname,colname,sizename from $tab join $tab1 on $tab.catid=$tab1.catid join $tab2 on $tab.subcatid=$tab2.subcatid join $tab3 on $tab.colid=$tab3.colid join $tab4 on $tab.sizeid=$tab4.sizeid order by pid asc";
	   
	   $ex=$c->query($sel);
	   
	   while($fet=$ex->fetch_array())
	   {
		   
		   
		   $arr[]=$fet;
		   
		   
	   }
	   
	   
	   return $arr;
		
		
	}
	
	
	
	

}



?>