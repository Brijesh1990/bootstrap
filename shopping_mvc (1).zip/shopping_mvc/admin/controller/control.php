<?php
include("model/model.php");
date_default_timezone_set("Asia/Calcutta");
error_reporting(0);

$obj=new model();


//for admin login write a logic...


if(isset($_POST["log"]))

{
   
   $em=$_POST["em"];
   
   
   $pass=$_POST["pass"];
   
  $obj->adminlog($c,'admin',$em,$pass);
	
	
}



//logout here

if(isset($_REQUEST["lg"]))

{
	
   
   $aid=$_SESSION["aid"];
   
   
   $obj->logout($aid);	
	
	
}


//for add or insert a category in table...

if(isset($_POST["addcategory"]))

{
	
  $catname=$_POST["cat"];
  
  $desc=$_POST["desc"];
  
  
  $data=array("catname"=>$catname,"description"=>$desc);
  
  $obj->insalldata($c,'category',$data);
  
  
  if($obj)
  {	
	
  echo "<script>
  
  alert('Categoey Added Succefully')
  
  
  window.location='showcategory.php';
  
  </script>";	
	
}


else
{
	
 echo "<script>
  
  alert('Sorry Categoey Not Added try again')
  
  
  window.location='addcategory.php';
  
  </script>";	
		
}



}


//for display category from category table...


$shw=$obj->shwalldata($c,'category');

//for delete category from table..

if(isset($_REQUEST["did"]))

{
$did=base64_decode($_REQUEST["did"]);

$obj->deldata($c,'category',$did);	
	
	
	
}



//for fetch category from category table..


if(isset($_REQUEST["eid"]))

{
   $eid=base64_decode($_REQUEST["eid"]);
   
   $ed=$obj->fetchcat($c,'category',$eid);	
	
}


//update category from table...


if(isset($_REQUEST["updcategory"]))

{
	
	
  $eid=base64_decode($_REQUEST["eid"]);
  
  	
  $catname=$_POST["cat"];
  
  $desc=$_POST["desc"];
  
  
  $obj->updcat($c,'category',$catname,$desc,$eid);
	
	
	
}

//fetch category in subcategory as a dropdown list dynamic data from table


$cat=$obj->shwalldata($c,'category');



//insert a subcategory data in addsubcategory tables...


if(isset($_REQUEST["addsubcategory"]))


{
   
   $cat=$_REQUEST["cat"];
   
   $subcat=$_REQUEST["subcat"];
   $created_date=date("d/m/y");
   $created_time=date("H:i:s a");
   $desc=$_REQUEST["desc"];
   
   
   $data=array("catid"=>$cat,"subcatname"=>$subcat,"created_date"=>$created_date,"created_time"=>$created_time,"description"=>$desc);
   
   
   $obj->insalldata($c,'subcategory',$data);	
	
  if($obj)
  {	
	
  echo "<script>
  
  alert('SubCategoey Added Succefully')
  
  
  window.location='showsubcategory.php';
  
  </script>";	
	
}


else
{
	
 echo "<script>
  
  alert('Sorry SubCategoey Not Added try again')
  
  
  window.location='addsubcategory.php';
  
  </script>";	
		
}


}




//show subcategory all data...


$subcat=$obj->shwsubcat($c,'subcategory','category');	
	
	
//for delete subcategory from table..

if(isset($_REQUEST["delsub"]))

{
$did=base64_decode($_REQUEST["delsub"]);

$obj->delsubdata($c,'subcategory',$did);	
	

	 echo "<script>
	 
	 alert('SubCategory Deleted succefully')
	 
	 window.location='showsubcatgory.php';
	 
	 
	 </script>";
   	
	
}


//edit subcategory..................

if(isset($_REQUEST["edsub"]))

{
	
	
	$eid=base64_decode($_REQUEST["edsub"]);
   
   $edsub=$obj->editsubcat($c,'subcategory','category',$eid);	
	
	
}


//update subcategory from table...


if(isset($_REQUEST["updsubcategory"]))

{
	
	
  $eid=base64_decode($_REQUEST["edsub"]);
  
  	
  $cat=$_POST["cat"];
  
  $subcat=$_POST["subcat"];
  
  
  $desc=$_POST["desc"];
  
  
  $obj->updsubcat($c,'subcategory',$cat,$subcat,$desc,$eid);
	
	
	
}


//insert a color data in color tables...


if(isset($_REQUEST["addcolor"]))


{
   
   $colname=$_REQUEST["colname"];
   
   
   $created_date=date("d/m/y");
   $created_time=date("H:i:s a");
   $desc=$_REQUEST["desc"];
   
   
   $data=array("colname"=>$colname,"created_date"=>$created_date,"created_time"=>$created_time,"description"=>$desc);
   
   
   $obj->insalldata($c,'color',$data);	
	
  if($obj)
  {	
	
  echo "<script>
  
  alert('Color Added Succefully')
  
  
  window.location='showcolor.php';
  
  </script>";	
	
}


else
{
	
 echo "<script>
  
  alert('Sorry Color Not Added try again')
  
  
  window.location='addcolor.php';
  
  </script>";	
		
}


}

//show all color
$color=$obj->shwalldata($c,'color');


//for delete subcategory from table..

if(isset($_REQUEST["delcol"]))

{
$did=base64_decode($_REQUEST["delcol"]);

$obj->delcolor($c,'color',$did);	
	

	 echo "<script>
	 
	 alert('Color Deleted succefully')
	 
	 window.location='showcolor.php';
	 
	 
	 </script>";
   	
	
}

//for fetch color from color table..


if(isset($_REQUEST["eidcol"]))

{
   $eid=base64_decode($_REQUEST["eidcol"]);
   
   $ed=$obj->fetchcol($c,'color',$eid);	
	
}

//update subcategory from table...


if(isset($_REQUEST["updcolor"]))

{
	
	
  $eid=base64_decode($_REQUEST["eidcol"]);
  
  	
  $colname=$_POST["colname"];
  
  
  $desc=$_POST["desc"];
  
  
  $obj->updcol($c,'color',$colname,$desc,$eid);
	
	
	
}

//insert a size data in color tables...


if(isset($_REQUEST["addsize"]))


{
   
   $sizename=$_REQUEST["sizename"];
   
   
   $created_date=date("d/m/y");
   $created_time=date("H:i:s a");
   $desc=$_REQUEST["desc"];
   
   
   $data=array("sizename"=>$sizename,"created_date"=>$created_date,"created_time"=>$created_time,"description"=>$desc);
   
   
   $obj->insalldata($c,'size',$data);	
	
  if($obj)
  {	
	
  echo "<script>
  
  alert('Size Added Succefully')
  
  
  window.location='showsize.php';
  
  </script>";	
	
}


else
{
	
 echo "<script>
  
  alert('Sorry Size Not Added try again')
  
  
  window.location='addsize.php';
  
  </script>";	
		
}


}

//show all size
$size=$obj->shwalldata($c,'size');






//for delete Size from table..

if(isset($_REQUEST["delsize"]))

{
$did=base64_decode($_REQUEST["delsize"]);

$obj->delsize($c,'size',$did);	
	

	 echo "<script>
	 
	 alert('Size Deleted succefully')
	 
	 window.location='showsize.php';
	 
	 
	 </script>";
   	
	
}





//for fetch Size from color table..


if(isset($_REQUEST["eidsize"]))

{
   $eid=base64_decode($_REQUEST["eidsize"]);
   
   $ed=$obj->fetchsize($c,'size',$eid);	
	
}




//update size from table...


if(isset($_REQUEST["updsize"]))

{
	
	
  $eid=base64_decode($_REQUEST["eidsize"]);
  
  	
  $sizename=$_POST["sizename"];
  
  
  $desc=$_POST["desc"];
  
  
  $obj->updsize($c,'size',$sizename,$desc,$eid);
	
	
	
}


//fetch subcategory in addproduct page.....


$subcategory=$obj->shwalldata($c,'subcategory');


//insert a data in product tables...


if(isset($_REQUEST["addproduct"]))

{
	
	$cat=$_REQUEST["cat"];
	$subcat=$_REQUEST["subcat"];
	$tmp=$_FILES["img"]["tmp_name"];
	$path="upload/".$_FILES["img"]["name"];
	move_uploaded_file($tmp,$path);
	$pname=$_REQUEST["pname"];
    $qty=$_REQUEST["qty"];
	$price=$_REQUEST["price"];
	$colname=$_REQUEST["colname"];
	
	$size=$_REQUEST["sizename"];
	$created_date=date("d/m/y");
	$created_time=date("H:i:s a");
	
	$desc=$_REQUEST["pdesc"];
	
	
	$data=array("catid"=>$cat,"subcatid"=>$subcat,"pimages"=>$path,"pname"=>$pname,"qty"=>$qty,"price"=>$price,"colid"=>$colname,"sizeid"=>$size,"created_date"=>$created_date,"created_time"=>$created_time,"pdescription"=>$desc);
	
	
	
$obj->insalldata($c,'product',$data);

 echo "<script>
	 
	 alert('Product Added succefully')
	 
	 window.location='showproduct.php';
	 
	 
	 </script>";
	
	
}



//show all products in admin...


$product=$obj->shwproduct($c,'product','category','subcategory','color','size',$pid);


?>