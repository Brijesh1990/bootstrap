 <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li id="menu-home" ><a href="dashboard.php"><i class="fa fa-tachometer"></i><span>Dashboard</span></a></li>
		        <li><a href="#"><i class="fa fa-user"></i><span>Manage All Users</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul>
		            <li><a href="grids.html">Show Users</a></li></a></li>		            
		          </ul>
		        </li>
		        <li id="menu-comunicacao" ><a href="#"><i class="fa fa-book"></i><span>Add Category</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul id="menu-comunicacao-sub" >
		            <li id="menu-mensagens" style="width: 120px" ><a href="addcategory.php">Add category</a>		              
		            </li>
		            <li id="menu-arquivos" ><a href="showcategory.php">Show Category</a></li>
		          </ul>
		        </li>
		          
                  
                  
                  
                  
                  
                  
		        <li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>Add subcategory</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul id="menu-academico-sub" >
		          	 <li id="menu-academico-boletim" ><a href="addsubcategory.php">Add subcategory</a></li>
		            <li id="menu-academico-avaliacoes" ><a href="showsubcatgory.php">Show Subcategory</a></li>		           
		          </ul>
		        </li>
                
                
                  <li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>Add Size</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul id="menu-academico-sub" >
		          	 <li id="menu-academico-boletim" ><a href="addsize.php">Add Size</a></li>
		            <li id="menu-academico-avaliacoes" ><a href="showsize.php">Show Size</a></li>		           
		          </ul>
		        </li>
                
                
                
                  <li id="menu-academico" ><a href=""><i class="fa fa-file-text"></i><span>Add Color</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul id="menu-academico-sub" >
		          	 <li id="menu-academico-boletim" ><a href="addcolor.php">Add Color</a></li>
		            <li id="menu-academico-avaliacoes" ><a href="showcolor.php">Show Color</a></li>		           
		          </ul>
		        </li>
                
                
                
                  <li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>Add Product</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul id="menu-academico-sub" >
		          	 <li id="menu-academico-boletim" ><a href="addproduct.php">Add Product</a></li>
		            <li id="menu-academico-avaliacoes" ><a href="showproduct.php">Show Product</a></li>		           
		          </ul>
		        </li>
                
                
                
                 <li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>Manage Feedback</span></a>
		          
		        </li> 
                
                
		          <li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>Send Mail</span></a>
		          
		        </li> 
		      
		             </ul>
		         </li>
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>