<?php
include_once("model/model.php");


$obj=new model();

//for fetch category...


$cat=$obj->selall($c,'category');



//select all product..


$prod=$obj->selall($c,'product');

//fetch product of category....


if(isset($_REQUEST["catid"]))

{
$catid=base64_decode($_REQUEST["catid"]);

$prod=$obj->selproduct($c,'product','category',$catid);	
	
	
}


//product details........


if(isset($_REQUEST["pid"]))

{
	
	
	$pid=base64_decode($_REQUEST["pid"]);
	
$prod=$obj->productdetails($c,'product',$pid);
	
	
}



//register user....


if(isset($_POST["adduser"]))

{
	include_once("credential.php");
	include_once("textlocal.class.php");

	$em=$_POST["em"];
	$p=$_POST["pass"];
	$f=$_POST["fname"];
	$ad=$_POST["address"];
	$mob=$_POST["mob"];
	$cnn=$_POST["country"];
	$snn=$_POST["state"];
	$ctnn=$_POST["city"];
	
	
	$data=array("email"=>$em,"password"=>$p,"fullname"=>$f,"address"=>$ad,"mobile"=>$mob,"cid"=>$cnn,"sid"=>$snn,"ctid"=>$ctnn);


$obj->insalluserdata($c,'user',$data);



$textlocal = new Textlocal(false, false, API_KEY);

	$numbers = array(MOBILE);

	$sender = 'TXTLCL';

	$otp=mt_rand(10000, 99999);

	$message = "Hello".$_POST["uname"]." This is your OTP :".$otp;

	try 

	{
	    $result = $textlocal->sendSms($numbers, $message, $sender);
	    
		setcookie('otp',$otp);
		
		echo "OTP successfylly send..";
		
		
	} 

	catch (Exception $e) 

	{
	    die('Error: ' . $e->getMessage());
	} 


if($obj)
{	
	echo "<script>
		alert('Thanx for registration. please verify your otp.')

		window.location='otp.php';

		</script>";
	}
	
else
{
	echo "<script>
		alert('Sorry you are not register.')

		window.location='register.php';

		</script>";
		}	
}
//for verify otp & authinicate user on login page...
if(isset($_POST['verify']))
{
	$otp=$_POST['otp'];
	if($_COOKIE['otp']==$otp)
	{
		echo "<script>
		alert('Conguratilations your mobile is verified')

		window.location='login.php';

		</script>";
	}
	else
	{
		echo "<script>
		alert('sorry, your otp is wrong.')

		window.location='otp.php';

		</script>";
	}	
}






	
	
	
	


//fetch country form country table..

$cn=$obj->selall($c,'country');



//fetch state form state table..

$sn=$obj->selall($c,'state');


//fetch city form city table..

$ctn=$obj->selall($c,'city');


//user login

if(isset($_POST["log"]))

{
	
  $em=$_POST["em"];
  
  $pass=$_POST["pass"];
  
  
  $obj->loguser($c,'user',$em,$pass);	
	
	
}


//for user profile

if(isset($_SESSION["uid"]))

{
	
    $uid=$_SESSION["uid"];	
	
	
	$pro=$obj->profile($c,'user','country','state','city',$uid);
	
}




?>