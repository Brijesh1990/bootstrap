<?php

define("API_KEY",'zogCRevesfE-biLazFDQsGfY7sJhozdQkCZ0neDioz');

define("MOBILE",$_POST["mob"]);

?>