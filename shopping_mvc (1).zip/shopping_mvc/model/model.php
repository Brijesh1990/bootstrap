<?php
include_once("config.php");

$obj=new connection();

$c=$obj->conn();


//create a model class

class model

{
	
	
	//create a member function fo fetch category in user site.....
	
	
	public function selall($c,$table)
	
	
	{
		
		 $sel="select * from $table";
		 
		 $ex=$c->query($sel);
		 
		 while($fet=$ex->fetch_array())
		 
		 {
			 
			 $arr[]=$fet; 
			 
		 }
		 
		 return $arr;
		
		
		
	}
	
	
	//for select products of category...
	
	
	public function selproduct($c,$table,$table1,$catid)
	
	{
	    
		$sel="select $table.*,catname from $table join $table1 on $table.catid=$table1.catid where $table.catid='$catid'";
		
		$ex=$c->query($sel);
		
		while($fet=$ex->fetch_array())
		
		{
		 
		 $arr[]=$fet;	
			
			
		}
		
		
		return $arr;
		
	}
	
	
	
	//show products details.......
	
	
	public function productdetails($c,$table,$pid)
	
	
	{
		
		 $sel="select * from $table where pid='$pid'";
		 
		 $ex=$c->query($sel);
		 
		 while($fet=$ex->fetch_array())
		 
		 {
			 
			 $arr[]=$fet; 
			 
		 }
		 
		 return $arr;
		
		
		
	}
	
	
	
	//register user create a member function
	
	
	public function insalluserdata($c,$table,$data)
	
	{
		
		$k=array_keys($data);
		
		$kk=implode(",",$k);
		
		$v=array_values($data);
		
		$vv=implode("','",$v);
		
		
 $ins="insert into $table($kk) values ('$vv')"; 
		
$ex=$c->query($ins);
		
		
		
		
		
		
	}
	
	
//for user login create a member function

public function loguser($c,$table,$em,$pass)

{
	
  $sel="select * from $table where email='$em' and password='$pass'";
  
  
  $ex=$c->query($sel);
  
  $fet=$ex->fetch_array();
  
  $no=$ex->num_rows;
  
  if($no > 0)
  
  {
	  
	  
	  $_SESSION["uid"]=$fet["uid"];
	  
	  $_SESSION["fname"]=$fet["fullname"]; 
	  
	  
	  $_SESSION["em"]=$fet["email"];
	  
	  
	  
	  echo "<script>
	  alert('You are Logged IN succefully')
	  
	  
	  window.location='profile.php';
	  
	  
	  </script>"; 
	  
  }
  
  
  else
  
  {
	
	  echo "<script>
	  alert('username & password are wrong')
	  
	  
	  window.location='login.php';
	  
	  
	  </script>"; 
	  
	  
  }
  
  
  
}
  
  //for user profile..
  
  public function profile($c,$table,$table1,$table2,$table3,$uid)
  
  {
	  
	  
	  $sel="select $table.*,cname,sname,ctname from $table join $table1 on $table.cid=$table1.cid join $table2 on $table.sid=$table2.sid join $table3 on $table.ctid=$table3.ctid where uid='$uid'";
	  
	  
	  
	  $ex=$c->query($sel);
	  
	  
	  $fet=$ex->fetch_array();
	  
	  
	  
	  $arr[]=$fet;
	  
	  
	  return $arr;
	  
  }
	
	
}
	
	

	

?>